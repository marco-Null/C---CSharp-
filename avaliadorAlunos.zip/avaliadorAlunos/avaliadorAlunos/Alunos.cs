﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace avaliadorAlunos
{
    internal class Alunos
    {
        public string nome { get; set; }
        public int idade { get; set; } 
        public string Ano { get; set; }
        public int RM { get; set; }
        public double nota1 { get; set; }
        public double nota2 { get; set; }
        public double nota3 { get; set; }
        public double notaAritimetica { get; set; }
        public string notaLetra { get; set; }
    }
}
