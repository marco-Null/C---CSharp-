﻿using System;
using avaliadorAlunos;

Alunos aluno1 = new Alunos();
Alunos aluno2 = new Alunos();
Alunos aluno3 = new Alunos();
Alunos aluno4 = new Alunos();
Alunos aluno5 = new Alunos();


    Console.Write("Digite o nome do 1° aluno: ");
    aluno1.nome = Console.ReadLine();

    Console.Write("Digite a idade do aluno: ");
    aluno1.idade = int.Parse(Console.ReadLine());

    Console.Write("Digite a Serie do aluno (ex: 1° ano, 2° ano): ");
    aluno1.Ano = Console.ReadLine();

    Console.Write("Digite o RM do aluno: ");
    aluno1.RM = int.Parse(Console.ReadLine());

    Console.Write("Digite a primeira nota do aluno: ");
    aluno1.nota1 = double.Parse(Console.ReadLine());

    Console.Write("Digite a segunda nota do aluno: ");
    aluno1.nota2 = double.Parse(Console.ReadLine());

    Console.Write("Digite a terceira nota do aluno: ");
    aluno1.nota3 = double.Parse(Console.ReadLine());

    aluno1.notaAritimetica = (aluno1.nota1 + aluno1.nota2 + aluno1.nota3) / 3;


Console.Clear();


Console.Write("Digite o nome 2° do aluno: ");
aluno2.nome = Console.ReadLine();

Console.Write("Digite a idade do aluno: ");
aluno2.idade = int.Parse(Console.ReadLine());

Console.Write("Digite a Serie do aluno (ex: 1° ano, 2° ano): ");
aluno2.Ano = Console.ReadLine();

Console.Write("Digite o RM do aluno: ");
aluno2.RM = int.Parse(Console.ReadLine());

Console.Write("Digite a primeira nota do aluno: ");
aluno2.nota1 = double.Parse(Console.ReadLine());

Console.Write("Digite a segunda nota do aluno: ");
aluno2.nota2 = double.Parse(Console.ReadLine());

Console.Write("Digite a terceira nota do aluno: ");
aluno2.nota3 = double.Parse(Console.ReadLine());

aluno2.notaAritimetica = (aluno2.nota1 + aluno2.nota2 + aluno2.nota3) / 3;

Console.Clear();


Console.Write("Digite o nome do 3° aluno: ");
aluno3.nome = Console.ReadLine();

Console.Write("Digite a idade do aluno: ");
aluno3.idade = int.Parse(Console.ReadLine());

Console.Write("Digite a Serie do aluno (ex: 1° ano, 2° ano): ");
aluno3.Ano = Console.ReadLine();

Console.Write("Digite o RM do aluno: ");
aluno3.RM = int.Parse(Console.ReadLine());

Console.Write("Digite a primeira nota do aluno: ");
aluno3.nota1 = double.Parse(Console.ReadLine());

Console.Write("Digite a segunda nota do aluno: ");
aluno3.nota2 = double.Parse(Console.ReadLine());

Console.Write("Digite a terceira nota do aluno: ");
aluno3.nota3 = double.Parse(Console.ReadLine());

aluno3.notaAritimetica = (aluno3.nota1 + aluno3.nota2 + aluno3.nota3) / 3;

Console.Clear();


Console.Write("Digite o nome do 4° aluno: ");
aluno4.nome = Console.ReadLine();

Console.Write("Digite a idade do aluno: ");
aluno4.idade = int.Parse(Console.ReadLine());

Console.Write("Digite a Serie do aluno (ex: 1° ano, 2° ano): ");
aluno4.Ano = Console.ReadLine();

Console.Write("Digite o RM do aluno: ");
aluno4.RM = int.Parse(Console.ReadLine());

Console.Write("Digite a primeira nota do aluno: ");
aluno4.nota1 = double.Parse(Console.ReadLine());

Console.Write("Digite a segunda nota do aluno: ");
aluno4.nota2 = double.Parse(Console.ReadLine());

Console.Write("Digite a terceira nota do aluno: ");
aluno4.nota3 = double.Parse(Console.ReadLine());

aluno4.notaAritimetica = (aluno4.nota1 + aluno4.nota2 + aluno4.nota3) / 3;


Console.Clear();


Console.Write("Digite o nome do 5° aluno: ");
aluno5.nome = Console.ReadLine();

Console.Write("Digite a idade do aluno: ");
aluno5.idade = int.Parse(Console.ReadLine());

Console.Write("Digite a Serie do aluno (ex: 1° ano, 2° ano): ");
aluno5.Ano = Console.ReadLine();

Console.Write("Digite o RM do aluno: ");
aluno5.RM = int.Parse(Console.ReadLine());

Console.Write("Digite a primeira nota do aluno: ");
aluno5.nota1 = double.Parse(Console.ReadLine());

Console.Write("Digite a segunda nota do aluno: ");
aluno5.nota2 = double.Parse(Console.ReadLine());

Console.Write("Digite a terceira nota do aluno: ");
aluno5.nota3 = double.Parse(Console.ReadLine());

aluno5.notaAritimetica = (aluno5.nota1 + aluno5.nota2 + aluno5.nota3) / 3;

Console.Clear();

if(aluno1.notaAritimetica <= 3)
{
    aluno1.notaLetra = "I";
}
else if(aluno1.notaAritimetica <= 6)
{
    aluno1.notaLetra = "R";
}
else if (aluno1.notaAritimetica <= 8)
{
    aluno1.notaLetra = "B";
}
else
{
    aluno1.notaLetra = "MB";
}


if (aluno2.notaAritimetica <= 3)
{
    aluno2.notaLetra = "I";
}
else if (aluno2.notaAritimetica <= 6)
{
    aluno2.notaLetra = "R";
}
else if (aluno2.notaAritimetica <= 8)
{
    aluno2.notaLetra = "B";
}
else
{
    aluno2.notaLetra = "MB";
}


if (aluno3.notaAritimetica <= 3)
{
    aluno3.notaLetra = "I";
}
else if (aluno3.notaAritimetica <= 6)
{
    aluno3.notaLetra = "R";
}
else if (aluno3.notaAritimetica <= 8)
{
    aluno3.notaLetra = "B";
}
else
{
    aluno3.notaLetra = "MB";
}


if (aluno4.notaAritimetica <= 3)
{
    aluno4.notaLetra = "I";
}
else if (aluno4.notaAritimetica <= 6)
{
    aluno4.notaLetra = "R";
}
else if (aluno4.notaAritimetica <= 8)
{
    aluno4.notaLetra = "B";
}
else
{
    aluno4.notaLetra = "MB";
}

if (aluno5.notaAritimetica <= 3)
{
    aluno5.notaLetra = "I";
}
else if (aluno5.notaAritimetica <= 6)
{
    aluno5.notaLetra = "R";
}
else if (aluno5.notaAritimetica <= 8)
{
    aluno5.notaLetra = "B";
}
else
{
    aluno5.notaLetra = "MB";
}


Console.WriteLine("Nome do aluno: " + aluno1.nome);
Console.WriteLine("Idade do aluno: " + aluno1.idade);
Console.WriteLine("Ano do aluno: " + aluno1.Ano);
Console.WriteLine("RM do aluno: " + aluno1.RM);
Console.WriteLine("Nota aritimética do aluno: " + aluno1.notaAritimetica);
Console.WriteLine("Nota ETEC: " + aluno1.notaLetra);

Console.WriteLine();

Console.WriteLine("Nome do aluno: " + aluno2.nome);
Console.WriteLine("Idade do aluno: " + aluno2.idade);
Console.WriteLine("Ano do aluno: " + aluno2.Ano);
Console.WriteLine("RM do aluno: " + aluno2.RM);
Console.WriteLine("Nota aritimética do aluno: " + aluno2.notaAritimetica);
Console.WriteLine("Nota ETEC: " + aluno2.notaLetra);


Console.WriteLine();

Console.WriteLine("Nome do aluno: " + aluno3.nome);
Console.WriteLine("Idade do aluno: " + aluno3.idade);
Console.WriteLine("Ano do aluno: " + aluno3.Ano);
Console.WriteLine("RM do aluno: " + aluno3.RM);
Console.WriteLine("Nota aritimética do aluno: " + aluno3.notaAritimetica);
Console.WriteLine("Nota ETEC: " + aluno3.notaLetra);


Console.WriteLine();

Console.WriteLine("Nome do aluno: " + aluno4.nome);
Console.WriteLine("Idade do aluno: " + aluno4.idade);
Console.WriteLine("Ano do aluno: " + aluno4.Ano);
Console.WriteLine("RM do aluno: " + aluno4.RM);
Console.WriteLine("Nota aritimética do aluno: " + aluno4.notaAritimetica);
Console.WriteLine("Nota ETEC: " + aluno4.notaLetra);


Console.WriteLine();

Console.WriteLine("Nome do aluno: " + aluno5.nome);
Console.WriteLine("Idade do aluno: " + aluno5.idade);
Console.WriteLine("Ano do aluno: " + aluno5.Ano);
Console.WriteLine("RM do aluno: " + aluno5.RM);
Console.WriteLine("Nota aritimética do aluno: " + aluno5.notaAritimetica);
Console.WriteLine("Nota ETEC: " + aluno5.notaLetra);



Console.WriteLine();




Console.ReadKey();